# Project2025

# Buggy Calculator 🐛

This is a sample Python calculator project created for Hacktoberfest contribution.  
The repository intentionally contains bugs/issues which contributors can fix.

### Issues Present
- Division by zero not handled.
- Wrong output in subtraction.
- Inconsistent function naming.
- Missing instructions in README.

### How to Use
Run the calculator:

